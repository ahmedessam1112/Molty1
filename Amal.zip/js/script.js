
function checkPassword() {
    const input = document.getElementById("passwordInput").value;
    if(input === "20/10") {
        window.location.href = "home.html";
    } else {
        document.getElementById("error").style.display = "block";
    }
}
